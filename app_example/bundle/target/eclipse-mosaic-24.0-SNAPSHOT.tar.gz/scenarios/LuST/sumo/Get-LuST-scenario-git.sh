#!/bin/bash

git clone https://github.com/lcodeca/LuSTScenario.git ./LuSTScenario

cd ./LuSTScenario
git checkout
cd ..